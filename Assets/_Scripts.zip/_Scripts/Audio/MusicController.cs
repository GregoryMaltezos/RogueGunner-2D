public enum MusicType
{
   Peacefull = 0,
   Combat = 1,
   Boss = 2
}