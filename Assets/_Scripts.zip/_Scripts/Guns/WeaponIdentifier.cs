using UnityEngine;

public class WeaponIdentifier : MonoBehaviour
{
    public int weaponID; // Unique identifier for the weapon
}
