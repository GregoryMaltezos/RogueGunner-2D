using UnityEngine;

public class DamageSource : MonoBehaviour
{
    public float damage = 10f; // Default damage amount

    public float GetDamage()
    {
        return damage;
    }
}
